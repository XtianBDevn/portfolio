</main>
<footer class="site-footer">
    <div class="container">
        <p>&copy; <?php echo date_i18n( 'Y' ); ?> Christian Bryant. All rights reserved.</p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>